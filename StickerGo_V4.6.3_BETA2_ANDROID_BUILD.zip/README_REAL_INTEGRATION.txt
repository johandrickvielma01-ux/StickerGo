STICKERGO V4 REAL — TikTok + Android integration

IMPORTANTE
-----------
Esta versión ya no trata el botón de TikTok como una simple demo:
- Incluye un Android plugin v2 para Godot 4.2+.
- El plugin usa el TikTok OpenSDK oficial.
- Login Kit usa OAuth/PKCE.
- La app NO pide la contraseña ni códigos de TikTok.
- El client_secret NO debe ir dentro de la APK; el intercambio del authorization code debe hacerse en servidor.

Qué falta configurar por TU cuenta
-----------------------------------
1. Crear la aplicación en TikTok for Developers.
2. Añadir Login Kit.
3. Registrar Android con el package name de StickerGo.
4. Añadir MD5 y SHA-256 del certificado con el que exportes StickerGo.
5. Configurar el redirect URI HTTPS autorizado por TikTok.
6. Copiar tu client_key en:
   android/plugin/src/main/java/com/stickergo/tiktok/TikTokConfig.kt
7. Para datos ampliados (por ejemplo actividad/favoritos compartidos), solicitar y obtener aprobación de los scopes correspondientes.
8. Instalar el Gradle Android build template de Godot y exportar con Gradle Build activado.

SDK oficial
-----------
La integración usa:
com.tiktok.open.sdk:tiktok-open-sdk-core:2.4.0
com.tiktok.open.sdk:tiktok-open-sdk-auth:2.4.0

El repositorio oficial indica que OpenSDK proporciona Login Kit y Share Kit.
La documentación actual de TikTok también exige client key, redirect URI HTTPS y PKCE para Android.

Qué hace esta V4 REAL
---------------------
- Botón "Conectar TikTok" llama al plugin nativo.
- El plugin abre TikTok (o el fallback de navegador).
- Recibe el callback oficial.
- Emite a Godot el authorization code y los permisos concedidos.
- Guarda el code_verifier localmente durante el flujo OAuth.
- NO expone client_secret dentro de la app.
- La interfaz de StickerGo muestra claramente si la cuenta está conectada.

Qué NO afirmamos todavía
------------------------
TikTok no ofrece en la documentación pública una API directa para "favoritos de stickers".
La Data Portability API sí documenta Favorite Videos y Share History, entre otros tipos de actividad.
Por eso la pantalla de Favoritos/Compartidos está preparada para datos reales, pero no vamos a fingir acceso a datos que TikTok no autorice.

WhatsApp
--------
La integración oficial de stickers permite crear packs y lanzar el flujo oficial para añadirlos a WhatsApp.
La documentación oficial indica 3–30 stickers por pack y 512×512 para cada sticker.
La lectura automática de los "favoritos internos" de WhatsApp no está disponible como API pública para terceros, así que esa parte seguirá separada hasta que exista una vía oficial.

Siguiente paso
--------------
Abre:
  android/plugin/src/main/java/com/stickergo/tiktok/TikTokConfig.kt

y sustituye:
  REPLACE_WITH_TIKTOK_CLIENT_KEY
  https://YOUR-DOMAIN.example/tiktok/callback

por los valores reales de tu app de TikTok.

Después sigue:
  SETUP_TIKTOK_REAL.md
