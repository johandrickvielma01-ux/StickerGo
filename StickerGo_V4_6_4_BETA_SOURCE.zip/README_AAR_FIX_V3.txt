StickerGo V4.6.3 BETA2 - AAR FIX V3

This package contains the corrected Android TikTok plugin source.

Main fixes:
- Correct TikTok AuthRequest import:
  com.tiktok.open.sdk.auth.AuthRequest
- Correct Godot 4 Android onMainCreate signature:
  override fun onMainCreate(activity: Activity?): View?
- Removed unsupported onMainNewIntent override.
- Removed obsolete response.authMsg usage.
- Uses current AuthApi/AuthRequest/PKCEUtils flow.
- Keeps TikTok client secret OUT of the APK and source.
- Keeps Gradle 8.11.1 + AndroidX configuration for the AAR build.

Build target:
  StickerGoTikTok-release.aar

IMPORTANT:
Uploading this ZIP to GitHub does not unpack/replace files in the repository.
The repository's active .github/workflows/build-aar.yml must be updated separately
if it still points to an older ZIP name.
