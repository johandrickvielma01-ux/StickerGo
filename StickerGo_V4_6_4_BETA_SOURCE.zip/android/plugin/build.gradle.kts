plugins {
    // AGP 8.7.x solo soporta hasta compileSdk 35 (ver release notes oficiales).
    // 8.10.x es la primera versión de la serie 8.x con soporte oficial para
    // compileSdk 36, y requiere Gradle >= 8.11.1 (ver AGP 8.10 release notes).
    id("com.android.library") version "8.10.1" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}
