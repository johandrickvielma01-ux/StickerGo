@tool
extends EditorExportPlugin

const PLUGIN_NAME := "StickerGoTikTok"

func _get_name() -> String:
	return PLUGIN_NAME

func _supports_platform(platform: EditorExportPlatform) -> bool:
	return platform is EditorExportPlatformAndroid

func _get_android_dependencies(platform: EditorExportPlatform, debug: bool) -> PackedStringArray:
	# TikTok OpenSDK Maven dependencies used by the AAR.
	return PackedStringArray([
		"com.tiktok.open.sdk:tiktok-open-sdk-core:2.4.0",
		"com.tiktok.open.sdk:tiktok-open-sdk-auth:2.4.0"
	])

func _get_android_dependencies_maven_repos(platform: EditorExportPlatform, debug: bool) -> PackedStringArray:
	return PackedStringArray([
		"https://artifact.bytedance.com/repository/AwemeOpenSDK"
	])

func _get_android_manifest_element_contents(platform: EditorExportPlatform, debug: bool) -> String:
	return """<queries>
		<package android:name="com.zhiliaoapp.musically"/>
		<package android:name="com.ss.android.ugc.trill"/>
		<package android:name="com.whatsapp"/>
		<package android:name="com.whatsapp.w4b"/>
		<intent>
			<action android:name="com.whatsapp.intent.action.ENABLE_STICKER_PACK"/>
		</intent>
	</queries>"""
