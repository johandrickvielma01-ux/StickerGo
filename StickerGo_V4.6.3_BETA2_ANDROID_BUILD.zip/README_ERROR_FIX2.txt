StickerGo V4 REAL - FIX 2

Corregido el error de Godot:
Unexpected identifier "_init_tiktok_bridge" in class body.

La llamada _init_tiktok_bridge() queda únicamente en _ready() de la clase principal. Se eliminó la llamada accidental que había quedado dentro de IconCanvas.
