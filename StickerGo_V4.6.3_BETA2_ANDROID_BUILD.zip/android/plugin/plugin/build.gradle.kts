plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}

val pluginName = "StickerGoTikTok"

android {
    namespace = "com.stickergo.tiktok"
    compileSdk = 36

    defaultConfig {
        minSdk = 24
        manifestPlaceholders["godotPluginName"] = pluginName
        manifestPlaceholders["godotPluginPackageName"] = "com.stickergo.tiktok"
        buildConfigField("String", "GODOT_PLUGIN_NAME", "\"$pluginName\"")
        buildConfigField("String", "TIKTOK_SDK_VERSION", "\"2.4.0\"")
        setProperty("archivesBaseName", pluginName)
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlin {
        jvmToolchain(17)
    }
}

dependencies {
    implementation("org.godotengine:godot:4.7.2.stable")

    implementation("com.tiktok.open.sdk:tiktok-open-sdk-core:2.4.0")
    implementation("com.tiktok.open.sdk:tiktok-open-sdk-auth:2.4.0")
}


// Copy the generated AAR into the Godot project's addon folder when building in CI.
val copyReleaseAAR by tasks.registering(Copy::class) {
    dependsOn("assembleRelease")
    from(layout.buildDirectory.dir("outputs/aar"))
    include("$pluginName-release.aar")
    into(project.rootProject.projectDir.resolve("../../addons/StickerGoTikTok/bin/release"))
}

val copyDebugAAR by tasks.registering(Copy::class) {
    dependsOn("assembleDebug")
    from(layout.buildDirectory.dir("outputs/aar"))
    include("$pluginName-debug.aar")
    into(project.rootProject.projectDir.resolve("../../addons/StickerGoTikTok/bin/debug"))
}
