# StickerGo server — token exchange

TikTok's current documentation recommends handling access/refresh tokens server-side.

The Android app should send the one-time authorization code and PKCE code verifier to your backend over HTTPS.

Do NOT place:
- client_secret
- refresh tokens
- long-lived access tokens

inside the APK.

The backend should exchange the code with TikTok's OAuth token endpoint and keep the resulting tokens securely.

This folder is intentionally a skeleton so the server can be deployed to the provider you choose.
