# Optional GDScript wrapper for the native Android singleton.
# The main StickerGo project uses Engine.has_singleton() directly.

class_name TikTokGodotBridge
extends RefCounted

const PLUGIN_NAME := "StickerGoTikTok"

var plugin = null

func _init() -> void:
    if Engine.has_singleton(PLUGIN_NAME):
        plugin = Engine.get_singleton(PLUGIN_NAME)

func available() -> bool:
    return plugin != null

func configured() -> bool:
    return plugin != null and plugin.isConfigured()

func login() -> void:
    if plugin:
        plugin.startLogin()
