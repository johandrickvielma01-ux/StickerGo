plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}

val pluginName = "StickerGoTikTok"

// Este es el reemplazo correcto de "archivesBaseName" para AGP 8.x / Gradle 8.x.
// "archivesBaseName" dentro de android{} (o android.defaultConfig{}) ya no es una
// propiedad válida en el DSL de Kotlin de AGP moderno; el equivalente soportado
// es "base.archivesName" a nivel de módulo. Esto hace que assembleRelease/
// assembleDebug generen exactamente:
//   plugin/build/outputs/aar/StickerGoTikTok-release.aar
//   plugin/build/outputs/aar/StickerGoTikTok-debug.aar
base {
    archivesName.set(pluginName)
}

android {
    namespace = "com.stickergo.tiktok"
    compileSdk = 36

    defaultConfig {
        minSdk = 24
        manifestPlaceholders["godotPluginName"] = pluginName
        manifestPlaceholders["godotPluginPackageName"] = "com.stickergo.tiktok"
        buildConfigField("String", "GODOT_PLUGIN_NAME", "\"$pluginName\"")
        buildConfigField("String", "TIKTOK_SDK_VERSION", "\"2.4.0\"")
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlin {
        jvmToolchain(17)
    }
}

dependencies {
    implementation("org.godotengine:godot:4.7.2.stable")

    implementation("com.tiktok.open.sdk:tiktok-open-sdk-core:2.4.0")
    implementation("com.tiktok.open.sdk:tiktok-open-sdk-auth:2.4.0")
}


// Copy the generated AAR into the Godot project's addon folder when building in CI.
val copyReleaseAAR by tasks.registering(Copy::class) {
    dependsOn("assembleRelease")
    from(layout.buildDirectory.dir("outputs/aar"))
    include("$pluginName-release.aar")
    into(project.rootProject.projectDir.resolve("../../addons/StickerGoTikTok/bin/release"))
}

val copyDebugAAR by tasks.registering(Copy::class) {
    dependsOn("assembleDebug")
    from(layout.buildDirectory.dir("outputs/aar"))
    include("$pluginName-debug.aar")
    into(project.rootProject.projectDir.resolve("../../addons/StickerGoTikTok/bin/debug"))
}
