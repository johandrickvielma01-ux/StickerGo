package com.stickergo.tiktok

object TikTokConfig {
    // PUBLIC client key. Never put client_secret here.
    const val CLIENT_KEY = "sbawudg1hrycwejpjm"

    // Must be HTTPS and match the redirect URI registered in TikTok.
    const val REDIRECT_URI = "https://johandrickvielma01-ux.github.io/tiktok/callback"

    // Basic login is available with Login Kit.
    // Add only scopes that your TikTok app has been approved to request.
    const val BASIC_SCOPE = "user.info.basic"

    // Example for an approved Display API scope:
    // const val SCOPE = "user.info.basic,video.list"
}
