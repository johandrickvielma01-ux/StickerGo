Reparación: se restauraron _load_local_state() y _save_local_state() en Main.gd para resolver el error de función inexistente.
