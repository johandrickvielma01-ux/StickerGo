extends Control

# ─── Estado ──────────────────────────────────────────────────────
var current_screen: String = "home"
var current_tiktok_tab: String = "fav"  # fav | shared | stickers
var sort_newest_first: bool = true
var selected: Dictionary = {}

var favorites: Array = []
var shared: Array = []
var tiktok_stickers: Array = []
var whatsapp_favorites: Array = []
var packs: Array = []

var content_box: VBoxContainer
var status_label: Label
var nav_buttons: Array[Button] = []
var media_scroll: ScrollContainer = null
var media_grid_host: VBoxContainer = null  # holds date sections
var loaded_until: int = 0
var flat_sorted_items: Array = []  # [{item, index, group}] for pagination

var tiktok_plugin = null
var tiktok_connected: bool = false
var tiktok_status: String = "desconectado"
var tiktok_last_error: String = ""
var tiktok_granted_scopes: String = ""
var last_auth_code: String = ""

# UI — fondo azul suave en tarjetas/iconos (cómodo, no agresivo)
const BG := Color("#060a12")
const PANEL := Color("#0d1524")
const PANEL_2 := Color("#152238")
const PANEL_ICON := Color("#12304a")  # azul para zonas de iconos
const BORDER := Color("#2a3d5c")
const MUTED := Color("#8b9bb8")
const WHITE := Color("#f4f7fc")
const PINK := Color("#e11d48")
const PURPLE := Color("#6366f1")
const GREEN := Color("#10b981")
const RED := Color("#ef4444")
const AMBER := Color("#f59e0b")
const BLUE := Color("#3b82f6")

const STATE_FILE := "user://stickergo_v462.json"
const WA_STICKER_MIN := 3
const WA_STICKER_MAX := 30
const WA_AUTHORITY_SUFFIX := ".stickercontentprovider"
const PAGE_SIZE := 24


func _save_local_state() -> void:
	var data := {
		"favorites": favorites,
		"shared": shared,
		"tiktok_stickers": tiktok_stickers,
		"whatsapp_favorites": whatsapp_favorites,
		"packs": packs,
		"tiktok_connected": tiktok_connected,
		"tiktok_granted_scopes": tiktok_granted_scopes,
		"sort_newest_first": sort_newest_first
	}
	var file := FileAccess.open(STATE_FILE, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data))
		file.close()

func _load_local_state() -> void:
	if not FileAccess.file_exists(STATE_FILE):
		if FileAccess.file_exists("user://stickergo_v45.json"):
			_migrate_file("user://stickergo_v45.json")
		elif FileAccess.file_exists("user://stickergo_v4.json"):
			_migrate_file("user://stickergo_v4.json")
		return
	var file := FileAccess.open(STATE_FILE, FileAccess.READ)
	if not file:
		return
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	_apply_parsed_state(parsed)

func _migrate_file(path: String) -> void:
	var file := FileAccess.open(path, FileAccess.READ)
	if not file:
		return
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	_apply_parsed_state(parsed)
	_save_local_state()

func _apply_parsed_state(parsed) -> void:
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	if parsed.has("favorites") and typeof(parsed["favorites"]) == TYPE_ARRAY:
		favorites = parsed["favorites"]
	if parsed.has("shared") and typeof(parsed["shared"]) == TYPE_ARRAY:
		shared = parsed["shared"]
	if parsed.has("tiktok_stickers") and typeof(parsed["tiktok_stickers"]) == TYPE_ARRAY:
		tiktok_stickers = parsed["tiktok_stickers"]
	if parsed.has("whatsapp_favorites") and typeof(parsed["whatsapp_favorites"]) == TYPE_ARRAY:
		whatsapp_favorites = parsed["whatsapp_favorites"]
	if parsed.has("packs") and typeof(parsed["packs"]) == TYPE_ARRAY:
		packs = parsed["packs"]
	if parsed.has("tiktok_connected"):
		tiktok_connected = bool(parsed["tiktok_connected"])
		tiktok_status = "conectado" if tiktok_connected else "desconectado"
	if parsed.has("tiktok_granted_scopes"):
		tiktok_granted_scopes = str(parsed["tiktok_granted_scopes"])
	if parsed.has("sort_newest_first"):
		sort_newest_first = bool(parsed["sort_newest_first"])


func _ui_scale() -> float:
	var vp_width := get_viewport_rect().size.x
	if vp_width <= 0.0:
		return 1.0
	return clamp(vp_width / 400.0, 0.85, 1.6)

func _fs(base: float) -> int:
	return int(round(base * _ui_scale()))


func _build_ui() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = BG
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	var m := _fs(16)
	margin.add_theme_constant_override("margin_left", m)
	margin.add_theme_constant_override("margin_right", m)
	margin.add_theme_constant_override("margin_top", m)
	margin.add_theme_constant_override("margin_bottom", m)
	add_child(margin)

	var main_vbox := VBoxContainer.new()
	main_vbox.add_theme_constant_override("separation", _fs(10))
	margin.add_child(main_vbox)

	var top_bar := HBoxContainer.new()
	top_bar.add_theme_constant_override("separation", _fs(10))
	main_vbox.add_child(top_bar)

	var app_title := Label.new()
	app_title.text = "StickerGo"
	app_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	app_title.add_theme_font_size_override("font_size", _fs(24))
	app_title.add_theme_color_override("font_color", WHITE)
	top_bar.add_child(app_title)

	status_label = Label.new()
	status_label.text = "StickerGo V4.6.2 · listo"
	status_label.add_theme_font_size_override("font_size", _fs(13))
	status_label.add_theme_color_override("font_color", MUTED)
	top_bar.add_child(status_label)

	var content_scroll := ScrollContainer.new()
	content_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	main_vbox.add_child(content_scroll)

	content_box = VBoxContainer.new()
	content_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content_box.add_theme_constant_override("separation", _fs(14))
	content_scroll.add_child(content_box)

	var nav_bar := HBoxContainer.new()
	nav_bar.add_theme_constant_override("separation", _fs(6))
	main_vbox.add_child(nav_bar)

	nav_buttons.clear()
	var nav_items := [
		["home", "⌂  Inicio"],
		["tiktok", "♪  TikTok"],
		["whatsapp", "◉  WhatsApp"],
		["packs", "▣  Packs"],
		["settings", "⚙  Ajustes"]
	]
	for entry in nav_items:
		var screen_name: String = entry[0]
		var b := _make_button(str(entry[1]), PANEL)
		b.custom_minimum_size = Vector2(0, _fs(56))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.set_meta("screen", screen_name)
		b.pressed.connect(func(target_screen: String = screen_name): _show_screen(target_screen))
		nav_bar.add_child(b)
		nav_buttons.append(b)

func _clear_content() -> void:
	if not is_instance_valid(content_box):
		return
	media_scroll = null
	media_grid_host = null
	loaded_until = 0
	flat_sorted_items.clear()
	for child in content_box.get_children():
		content_box.remove_child(child)
		child.queue_free()

func _show_screen(screen: String) -> void:
	current_screen = screen
	selected.clear()
	_refresh()

func _refresh() -> void:
	if not is_instance_valid(content_box):
		return
	_clear_content()
	match current_screen:
		"tiktok":
			_tiktok_screen()
		"whatsapp":
			_whatsapp_screen()
		"packs":
			_packs_screen()
		"settings":
			_settings_screen()
		_:
			_home_screen()
	_update_nav_highlight()
	_update_status()

func _update_nav_highlight() -> void:
	for b in nav_buttons:
		if not is_instance_valid(b):
			continue
		var screen_name: String = str(b.get_meta("screen", ""))
		var active := screen_name == current_screen
		var fill := PINK if active else PANEL
		b.add_theme_stylebox_override("normal", _box(fill, 18, BORDER, 1))
		b.add_theme_stylebox_override("hover", _box(fill.lightened(0.10), 18, WHITE, 1))
		b.add_theme_stylebox_override("pressed", _box(fill.darkened(0.10), 18, WHITE, 2))


func _ready() -> void:
	_build_ui()
	_init_tiktok_bridge()
	_load_local_state()
	_refresh()

func _init_tiktok_bridge() -> void:
	if Engine.has_singleton("StickerGoTikTok"):
		tiktok_plugin = Engine.get_singleton("StickerGoTikTok")
		if tiktok_plugin.has_signal("tiktok_auth_success"):
			tiktok_plugin.tiktok_auth_success.connect(_on_tiktok_auth_success)
		if tiktok_plugin.has_signal("tiktok_auth_error"):
			tiktok_plugin.tiktok_auth_error.connect(_on_tiktok_auth_error)
		if tiktok_plugin.has_signal("tiktok_auth_started"):
			tiktok_plugin.tiktok_auth_started.connect(_on_tiktok_auth_started)

func _start_tiktok_login() -> void:
	if tiktok_plugin == null:
		_show_notice("Plugin Android no cargado en esta APK.\n\n1) Prepara el plugin Android con Gradle (ver BUILD_ANDROID_PLUGIN.md).\nDespués activa el plugin + Use Gradle Build y vuelve a exportar.")
		return
	if not tiktok_plugin.isConfigured():
		_show_notice("Falta configurar TikTokConfig.kt con Client Key y redirect HTTPS.\n\nNo se guarda Client Secret en la APK.")
		return
	tiktok_status = "conectando"
	tiktok_last_error = ""
	_update_status()
	_refresh()
	tiktok_plugin.startLogin()

func _start_tiktok_login_browser() -> void:
	if tiktok_plugin == null:
		_show_notice("Plugin Android no cargado.\nSigue BUILD_ANDROID_PLUGIN.md y vuelve a exportar con Gradle Build.")
		return
	if not tiktok_plugin.isConfigured():
		_show_notice("Falta configurar TikTokConfig.kt.")
		return
	tiktok_status = "conectando"
	tiktok_last_error = ""
	_update_status()
	tiktok_plugin.startLoginInBrowser()

func _disconnect_tiktok() -> void:
	tiktok_connected = false
	tiktok_status = "desconectado"
	tiktok_granted_scopes = ""
	last_auth_code = ""
	_save_local_state()
	_show_notice("TikTok desconectado en este dispositivo.")
	_refresh()

func _on_tiktok_auth_started(method: String) -> void:
	tiktok_status = "conectando"
	_update_status()
	_show_notice("Abriendo autorización oficial de TikTok…\nMétodo: " + method)

func _on_tiktok_auth_success(auth_code: String, granted_permissions: String) -> void:
	tiktok_connected = true
	tiktok_status = "conectado"
	tiktok_granted_scopes = granted_permissions
	last_auth_code = auth_code
	tiktok_last_error = ""
	_save_local_state()
	_show_screen("tiktok")
	_show_notice("TikTok autorizado.\n\nPermisos: " + granted_permissions + "\n\nEl code se intercambia solo en tu servidor.")

func _on_tiktok_auth_error(message: String) -> void:
	tiktok_status = "error"
	tiktok_last_error = message
	tiktok_connected = false
	_update_status()
	_show_notice("TikTok: " + message)
	_refresh()


func _home_screen() -> void:
	_section_title("Todo en un solo lugar", "V4.6.2 · galería por fechas · stickers TikTok · optimizado.")
	content_box.add_child(_make_big_card("♪", "TikTok → WhatsApp", "Favoritos, Compartidos y Stickers. Orden y fechas."))
	var b1 := _make_button("♪  Abrir TikTok", PINK)
	b1.pressed.connect(func(): _show_screen("tiktok"))
	content_box.add_child(b1)
	content_box.add_child(_make_big_card("◉", "WhatsApp → TikTok", "Elige stickers y prepáralos. Detecta si WhatsApp está instalado."))
	var b2 := _make_button("◉  Abrir WhatsApp", GREEN)
	b2.pressed.connect(func(): _show_screen("whatsapp"))
	content_box.add_child(b2)
	content_box.add_child(_make_big_card("▣", "Packs", "Crea packs 3–30 y añádelos a WhatsApp."))
	var b3 := _make_button("▣  Gestionar packs", PURPLE)
	b3.pressed.connect(func(): _show_screen("packs"))
	content_box.add_child(b3)


func _tiktok_screen() -> void:
	_section_title("TikTok", "Favoritos · Compartidos · Stickers · por fecha.")

	var status_card := _make_big_card(_tiktok_status_icon(), _tiktok_status_title(), _tiktok_status_detail())
	content_box.add_child(status_card)

	if tiktok_status == "conectado":
		var disc := _make_button("⎋  Desconectar TikTok", RED)
		disc.custom_minimum_size = Vector2(0, _fs(52))
		disc.pressed.connect(_disconnect_tiktok)
		content_box.add_child(disc)
	else:
		var connect := _make_button("♪  Conectar TikTok", PINK)
		connect.custom_minimum_size = Vector2(0, _fs(56))
		connect.pressed.connect(_start_tiktok_login)
		content_box.add_child(connect)
		var browser := _make_button("🌐  Conectar con navegador", PANEL_2)
		browser.custom_minimum_size = Vector2(0, _fs(50))
		browser.pressed.connect(_start_tiktok_login_browser)
		content_box.add_child(browser)

	# Tabs
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", _fs(6))
	content_box.add_child(tabs)
	for t in [["fav", "♥ Fav"], ["shared", "↗ Comp"], ["stickers", "✦ Stickers"]]:
		var active: bool = current_tiktok_tab == str(t[0])
		var col := PINK if (active and t[0] == "fav") else (PURPLE if (active and t[0] == "shared") else (BLUE if (active and t[0] == "stickers") else PANEL))
		var tb := _make_button(str(t[1]), col)
		tb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		tb.custom_minimum_size = Vector2(0, _fs(52))
		var key: String = t[0]
		tb.pressed.connect(func(k: String = key): _switch_tiktok_tab(k))
		tabs.add_child(tb)

	# Sort
	var sort_row := HBoxContainer.new()
	sort_row.add_theme_constant_override("separation", _fs(6))
	content_box.add_child(sort_row)
	var newest := _make_button("↓ Más recientes", BLUE if sort_newest_first else PANEL_2)
	var oldest := _make_button("↑ Más viejos", BLUE if not sort_newest_first else PANEL_2)
	newest.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	oldest.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	newest.custom_minimum_size = Vector2(0, _fs(48))
	oldest.custom_minimum_size = Vector2(0, _fs(48))
	newest.pressed.connect(func(): _set_sort(true))
	oldest.pressed.connect(func(): _set_sort(false))
	sort_row.add_child(newest)
	sort_row.add_child(oldest)

	var items := _current_tiktok_items()
	var group := current_tiktok_tab
	var name := _tab_display_name(group)

	if not tiktok_connected and items.is_empty():
		var warn := Label.new()
		warn.text = "Conecta TikTok para sincronizar. Los listados reales requieren scopes aprobados (sin scraping)."
		warn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		warn.add_theme_font_size_override("font_size", _fs(14))
		warn.add_theme_color_override("font_color", AMBER)
		content_box.add_child(warn)
	elif items.is_empty():
		var empty := Label.new()
		empty.text = "Requiere autorización de TikTok o aún no hay datos en %s.\nCuando haya vídeos/stickers, se agrupan por fecha." % name
		empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		empty.add_theme_font_size_override("font_size", _fs(15))
		empty.add_theme_color_override("font_color", MUTED)
		content_box.add_child(empty)

	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", _fs(8))
	content_box.add_child(header)
	var label := Label.new()
	label.text = "%s  ·  %d" % [name, items.size()]
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.add_theme_font_size_override("font_size", _fs(20))
	label.add_theme_color_override("font_color", WHITE)
	header.add_child(label)
	var count := Label.new()
	count.text = "%d sel." % _selected_count(group)
	count.add_theme_font_size_override("font_size", _fs(14))
	count.add_theme_color_override("font_color", MUTED)
	header.add_child(count)

	# Scroll + infinite host
	media_scroll = ScrollContainer.new()
	media_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	media_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	media_scroll.scroll_ended.connect(_on_media_scroll_ended)
	content_box.add_child(media_scroll)

	media_grid_host = VBoxContainer.new()
	media_grid_host.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	media_grid_host.add_theme_constant_override("separation", _fs(12))
	media_scroll.add_child(media_grid_host)

	_rebuild_flat_list()
	_load_more_media_tiles()

	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", _fs(8))
	content_box.add_child(actions)
	var all := _make_button("☑ Todos", PANEL_2)
	all.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	all.custom_minimum_size = Vector2(0, _fs(52))
	all.pressed.connect(_select_all_current_tiktok)
	actions.add_child(all)
	var del := _make_button("⌫ Eliminar", RED)
	del.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	del.custom_minimum_size = Vector2(0, _fs(52))
	del.pressed.connect(_confirm_delete_current_tiktok)
	actions.add_child(del)

	var to_pack := _make_button("▣ Crear pack con selección", GREEN)
	to_pack.custom_minimum_size = Vector2(0, _fs(52))
	to_pack.pressed.connect(_create_pack_from_tiktok_selection)
	content_box.add_child(to_pack)


func _tab_display_name(group: String) -> String:
	match group:
		"shared":
			return "Compartidos"
		"stickers":
			return "Stickers TikTok"
		_:
			return "Favoritos"

func _current_tiktok_items() -> Array:
	match current_tiktok_tab:
		"shared":
			return shared
		"stickers":
			return tiktok_stickers
		_:
			return favorites

func _set_sort(newest: bool) -> void:
	sort_newest_first = newest
	_save_local_state()
	selected.clear()
	_show_screen("tiktok")

func _switch_tiktok_tab(group: String) -> void:
	current_tiktok_tab = group
	selected.clear()
	_show_screen("tiktok")

func _item_date_key(item: Dictionary) -> String:
	if item.has("date") and str(item["date"]) != "":
		return str(item["date"])
	if item.has("created_at") and str(item["created_at"]) != "":
		return str(item["created_at"]).substr(0, 10)
	return "sin-fecha"

func _format_date_label(key: String) -> String:
	if key == "sin-fecha":
		return "Sin fecha"
	# YYYY-MM-DD → texto legible simple
	var parts := key.split("-")
	if parts.size() >= 3:
		var months := ["", "enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]
		var m := int(parts[1])
		var d := int(parts[2])
		var y := parts[0]
		var mon: String = str(months[m]) if m >= 1 and m <= 12 else str(parts[1])
		return "%d de %s de %s" % [d, mon, y]
	return key

func _rebuild_flat_list() -> void:
	flat_sorted_items.clear()
	loaded_until = 0
	var items := _current_tiktok_items()
	var indices: Array = []
	for i in range(items.size()):
		indices.append(i)
	indices.sort_custom(func(a, b):
		var da := _item_date_key(items[a])
		var db := _item_date_key(items[b])
		if da == db:
			return (a > b) if sort_newest_first else (a < b)
		if sort_newest_first:
			return da > db
		return da < db
	)
	var group := current_tiktok_tab
	for idx in indices:
		flat_sorted_items.append({"item": items[idx], "index": idx, "group": group})

func _on_media_scroll_ended() -> void:
	_load_more_media_tiles()

func _load_more_media_tiles() -> void:
	if media_grid_host == null or not is_instance_valid(media_grid_host):
		return
	if loaded_until >= flat_sorted_items.size():
		return
	var end: int = mini(loaded_until + PAGE_SIZE, flat_sorted_items.size())
	var last_date := ""
	# Find last date label already in host
	if media_grid_host.get_child_count() > 0:
		var last_child = media_grid_host.get_child(media_grid_host.get_child_count() - 1)
		if last_child.has_meta("date_key"):
			last_date = str(last_child.get_meta("date_key"))

	var current_grid: GridContainer = null
	if last_date != "" and media_grid_host.get_child_count() > 0:
		var maybe = media_grid_host.get_child(media_grid_host.get_child_count() - 1)
		if maybe is GridContainer:
			current_grid = maybe

	for i in range(loaded_until, end):
		var entry: Dictionary = flat_sorted_items[i]
		var item: Dictionary = entry["item"]
		var idx: int = entry["index"]
		var group: String = entry["group"]
		var dk := _item_date_key(item)
		if dk != last_date:
			last_date = dk
			var date_lbl := Label.new()
			date_lbl.text = _format_date_label(dk)
			date_lbl.add_theme_font_size_override("font_size", _fs(17))
			date_lbl.add_theme_color_override("font_color", BLUE)
			date_lbl.set_meta("date_key", dk)
			media_grid_host.add_child(date_lbl)
			current_grid = GridContainer.new()
			current_grid.columns = _responsive_columns()
			current_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			current_grid.add_theme_constant_override("h_separation", _fs(8))
			current_grid.add_theme_constant_override("v_separation", _fs(10))
			current_grid.set_meta("date_key", dk)
			media_grid_host.add_child(current_grid)
		if current_grid == null:
			current_grid = GridContainer.new()
			current_grid.columns = _responsive_columns()
			current_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			current_grid.add_theme_constant_override("h_separation", _fs(8))
			current_grid.add_theme_constant_override("v_separation", _fs(10))
			media_grid_host.add_child(current_grid)
		if group == "stickers":
			_add_sticker_tile_tiktok(current_grid, item, idx)
		else:
			_add_media_tile(current_grid, item, idx, group)
	loaded_until = end

	if loaded_until < flat_sorted_items.size():
		var more := Label.new()
		more.text = "Desliza para cargar más… (%d / %d)" % [loaded_until, flat_sorted_items.size()]
		more.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		more.add_theme_font_size_override("font_size", _fs(13))
		more.add_theme_color_override("font_color", MUTED)
		more.set_meta("loader_hint", true)
		# remove previous hints
		for c in media_grid_host.get_children():
			if c.has_meta("loader_hint"):
				c.queue_free()
		media_grid_host.add_child(more)


func _tiktok_status_icon() -> String:
	match tiktok_status:
		"conectado":
			return "✓"
		"conectando":
			return "…"
		"error":
			return "!"
		_:
			return "♪"

func _tiktok_status_title() -> String:
	match tiktok_status:
		"conectado":
			return "Conectado a TikTok"
		"conectando":
			return "Conectando…"
		"error":
			return "Error de conexión"
		_:
			return "Desconectado"

func _tiktok_status_detail() -> String:
	match tiktok_status:
		"conectado":
			return "Scopes: " + (tiktok_granted_scopes if tiktok_granted_scopes != "" else "user.info.basic")
		"conectando":
			return "Esperando autorización oficial de TikTok…"
		"error":
			return tiktok_last_error if tiktok_last_error != "" else "No se pudo completar el OAuth."
		_:
			return "Pulsa Conectar TikTok para el flujo OAuth oficial."


func _whatsapp_screen() -> void:
	_section_title("WhatsApp", "Stickers hacia TikTok · packs oficiales · sin SMS.")

	var wa_installed := _is_whatsapp_installed()
	var status_text := "WhatsApp instalado" if wa_installed else "WhatsApp no instalado"
	var status_detail := "Listo para packs y selección de stickers." if wa_installed else "Instala WhatsApp desde Google Play para continuar."
	content_box.add_child(_make_big_card("◉" if wa_installed else "!", status_text, status_detail))

	if not wa_installed:
		var install_btn := _make_button("⬇  Instalar WhatsApp", GREEN)
		install_btn.custom_minimum_size = Vector2(0, _fs(56))
		install_btn.pressed.connect(_open_whatsapp_store)
		content_box.add_child(install_btn)

	var go_packs := _make_button("▣  Ir a Packs / Añadir a WhatsApp", GREEN if wa_installed else PANEL_2)
	go_packs.custom_minimum_size = Vector2(0, _fs(56))
	go_packs.pressed.connect(func(): _show_screen("packs"))
	content_box.add_child(go_packs)

	var note := Label.new()
	note.text = "Elige stickers abajo y prepáralos para TikTok.\nStickerGo no lee el almacenamiento privado de WhatsApp."
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.add_theme_font_size_override("font_size", _fs(14))
	note.add_theme_color_override("font_color", MUTED)
	content_box.add_child(note)

	var header := HBoxContainer.new()
	content_box.add_child(header)
	var hl := Label.new()
	hl.text = "Stickers  ·  %d" % whatsapp_favorites.size()
	hl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hl.add_theme_font_size_override("font_size", _fs(18))
	hl.add_theme_color_override("font_color", WHITE)
	header.add_child(hl)
	var hc := Label.new()
	hc.text = "%d sel." % _selected_count("wa")
	hc.add_theme_font_size_override("font_size", _fs(14))
	hc.add_theme_color_override("font_color", MUTED)
	header.add_child(hc)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	content_box.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = _responsive_columns()
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation", _fs(8))
	grid.add_theme_constant_override("v_separation", _fs(10))
	scroll.add_child(grid)
	for i in range(whatsapp_favorites.size()):
		_add_sticker_tile(grid, whatsapp_favorites[i], i)

	var export := _make_button("↗  Preparar seleccionados para TikTok", PINK)
	export.custom_minimum_size = Vector2(0, _fs(56))
	export.pressed.connect(_prepare_wa_for_tiktok)
	content_box.add_child(export)


func _prepare_wa_for_tiktok() -> void:
	var n := _selected_count("wa")
	if n == 0:
		_show_notice("Selecciona al menos un sticker de WhatsApp para prepararlo hacia TikTok.")
		return
	_show_notice("Preparados %d sticker(s) para TikTok.\n\nLa publicación automática solo estará disponible si TikTok ofrece una API oficial compatible. Puedes exportar contenido compatible manualmente." % n)


func _packs_screen() -> void:
	_section_title("Packs", "3–30 stickers · 512×512 WebP · sin mezclar static/animated.")
	var create := _make_button("＋  Crear nuevo pack", PURPLE)
	create.custom_minimum_size = Vector2(0, _fs(56))
	create.pressed.connect(_create_new_pack)
	content_box.add_child(create)
	if packs.is_empty():
		var empty := Label.new()
		empty.text = "Aún no hay packs.\nCrea uno o genera desde la selección de TikTok / Stickers."
		empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		empty.add_theme_font_size_override("font_size", _fs(15))
		empty.add_theme_color_override("font_color", MUTED)
		content_box.add_child(empty)
		return
	for i in range(packs.size()):
		var p: Dictionary = packs[i]
		var sticker_count: int = 0
		if p.has("stickers") and typeof(p["stickers"]) == TYPE_ARRAY:
			sticker_count = p["stickers"].size()
		var valid := sticker_count >= WA_STICKER_MIN and sticker_count <= WA_STICKER_MAX
		var desc := "%d stickers · %s · %s" % [sticker_count, str(p.get("author", "StickerGo")), str(p.get("status", "borrador"))]
		if not valid:
			desc += " · necesita %d–%d" % [WA_STICKER_MIN, WA_STICKER_MAX]
		content_box.add_child(_make_big_card("▣", str(p.get("name", "Pack")), desc))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", _fs(8))
		content_box.add_child(row)
		var add_wa := _make_button("➕  Añadir a WhatsApp", GREEN if valid else PANEL_2)
		add_wa.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		add_wa.custom_minimum_size = Vector2(0, _fs(50))
		var pack_index := i
		add_wa.pressed.connect(func(idx: int = pack_index): _add_pack_to_whatsapp(idx))
		row.add_child(add_wa)
		var del := _make_button("⌫", RED)
		del.custom_minimum_size = Vector2(_fs(60), _fs(50))
		del.pressed.connect(func(idx: int = pack_index): _delete_pack(idx))
		row.add_child(del)


func _settings_screen() -> void:
	_section_title("Ajustes", "Cuentas, privacidad y rendimiento.")
	var tt := _make_button("♪  TikTok  ·  " + _tiktok_status_title(), PINK)
	tt.custom_minimum_size = Vector2(0, _fs(58))
	tt.pressed.connect(func(): _show_screen("tiktok"))
	content_box.add_child(tt)
	var wa := _make_button("◉  WhatsApp  ·  " + ("instalado" if _is_whatsapp_installed() else "no instalado"), GREEN)
	wa.custom_minimum_size = Vector2(0, _fs(58))
	wa.pressed.connect(func(): _show_screen("whatsapp"))
	content_box.add_child(wa)
	var diag := _make_button("🔧  Diagnóstico de conexiones", BLUE)
	diag.custom_minimum_size = Vector2(0, _fs(58))
	diag.pressed.connect(_show_connection_diagnostics)
	content_box.add_child(diag)

	var priv := _make_button("◆  Privacidad", PURPLE)
	priv.custom_minimum_size = Vector2(0, _fs(58))
	priv.pressed.connect(func(): _show_notice("Sin contraseñas, SMS ni cookies de otras apps.\nOAuth TikTok oficial.\nStickers WhatsApp vía intent público.\nClient Secret solo en servidor."))
	content_box.add_child(priv)
	var opt := _make_button("⚡  Rendimiento", BLUE)
	opt.custom_minimum_size = Vector2(0, _fs(58))
	opt.pressed.connect(func(): _show_notice("Galerías con carga por partes (%d ítems por página).\nAgrupado por fecha.\nUI ligera para miles de favoritos." % PAGE_SIZE))
	content_box.add_child(opt)
	var save := _make_button("💾  Guardar estado local", PANEL)
	save.custom_minimum_size = Vector2(0, _fs(54))
	save.pressed.connect(func():
		_save_local_state()
		_show_notice("Estado guardado en el dispositivo.")
	)
	content_box.add_child(save)


func _show_connection_diagnostics() -> void:
	var tiktok_plugin_ok := tiktok_plugin != null
	var tiktok_config_ok := false
	var tiktok_installed := false
	var whatsapp_installed := false
	if tiktok_plugin_ok:
		if tiktok_plugin.has_method("isConfigured"):
			tiktok_config_ok = bool(tiktok_plugin.isConfigured())
		if tiktok_plugin.has_method("isTikTokInstalled"):
			tiktok_installed = bool(tiktok_plugin.isTikTokInstalled())
		if tiktok_plugin.has_method("isWhatsAppInstalled"):
			whatsapp_installed = bool(tiktok_plugin.isWhatsAppInstalled())

	var lines: Array[String] = []
	lines.append("StickerGo V4.6.2")
	lines.append("")
	lines.append("TikTok")
	lines.append("• Plugin Android: " + ("OK" if tiktok_plugin_ok else "NO CARGADO"))
	lines.append("• Configuración: " + ("OK" if tiktok_config_ok else "PENDIENTE"))
	lines.append("• App instalada: " + ("SÍ" if tiktok_installed else "NO / no detectada"))
	lines.append("• Estado OAuth: " + _tiktok_status_title())
	lines.append("")
	lines.append("WhatsApp")
	lines.append("• App instalada: " + ("SÍ" if whatsapp_installed else "NO / no detectada"))
	lines.append("• Integración: pack oficial + confirmación en WhatsApp")
	lines.append("")
	lines.append("Importante")
	lines.append("• StickerGo no pide contraseñas ni códigos SMS.")
	lines.append("• TikTok usa OAuth oficial cuando el plugin está configurado.")
	lines.append("• Los stickers privados de Favoritos de WhatsApp no se leen desde otra app.")
	lines.append("• Para un pack real hacen falta WebP 512×512 y ContentProvider.")

	_show_notice("\n".join(lines))

func _create_new_pack() -> void:
	var id := "pack_%d" % Time.get_unix_time_from_system()
	packs.append({
		"id": id,
		"name": "Mi pack %d" % (packs.size() + 1),
		"author": "StickerGo",
		"stickers": [],
		"status": "borrador",
		"created_at": Time.get_datetime_string_from_system()
	})
	_save_local_state()
	_show_notice("Pack creado.\nAñade entre %d y %d stickers antes de enviarlo a WhatsApp." % [WA_STICKER_MIN, WA_STICKER_MAX])
	_refresh()

func _create_pack_from_tiktok_selection() -> void:
	var items := _current_tiktok_items()
	var group := current_tiktok_tab
	var chosen: Array = []
	for key in selected.keys():
		var parts := str(key).split(":")
		if parts.size() == 2 and parts[0] == group:
			var idx := int(parts[1])
			if idx >= 0 and idx < items.size():
				chosen.append(items[idx])
	if chosen.is_empty():
		_show_notice("Selecciona al menos un elemento.")
		return
	if chosen.size() > WA_STICKER_MAX:
		_show_notice("WhatsApp permite máximo %d por pack. Seleccionaste %d." % [WA_STICKER_MAX, chosen.size()])
		return
	packs.append({
		"id": "pack_%d" % Time.get_unix_time_from_system(),
		"name": "Desde TikTok %d" % (packs.size() + 1),
		"author": "StickerGo",
		"stickers": chosen.duplicate(true),
		"status": "preparado" if chosen.size() >= WA_STICKER_MIN else "borrador",
		"created_at": Time.get_datetime_string_from_system()
	})
	_save_local_state()
	selected.clear()
	_show_notice("Pack creado con %d elementos.\nPara WhatsApp real: WebP 512×512 + ContentProvider." % chosen.size())
	_show_screen("packs")

func _delete_pack(index: int) -> void:
	if index < 0 or index >= packs.size():
		return
	packs.remove_at(index)
	_save_local_state()
	_show_notice("Pack eliminado.")
	_refresh()

func _add_pack_to_whatsapp(index: int) -> void:
	if index < 0 or index >= packs.size():
		return
	var p: Dictionary = packs[index]
	var sticker_count: int = 0
	if p.has("stickers") and typeof(p["stickers"]) == TYPE_ARRAY:
		sticker_count = p["stickers"].size()
	if sticker_count < WA_STICKER_MIN or sticker_count > WA_STICKER_MAX:
		_show_notice("WhatsApp exige entre %d y %d stickers.\nEste pack tiene %d." % [WA_STICKER_MIN, WA_STICKER_MAX, sticker_count])
		return
	if not _is_whatsapp_installed():
		_show_notice("WhatsApp no está instalado.\nUsa el botón Instalar WhatsApp para abrir Google Play.")
		return
	if tiktok_plugin == null or not tiktok_plugin.has_method("addStickerPackToWhatsApp"):
		_show_notice("Plugin Android no disponible.\nExporta con Gradle Build con el plugin Android preparado.")
		return
	var authority := "com.stickergo.app" + WA_AUTHORITY_SUFFIX
	var ok: bool = tiktok_plugin.addStickerPackToWhatsApp(authority, str(p.get("id", "pack")), str(p.get("name", "StickerGo")))
	if ok:
		p["status"] = "enviado_a_whatsapp"
		_save_local_state()
		_show_notice("Intent enviado a WhatsApp.\nConfirma la instalación del pack allí.")
	else:
		_show_notice("No se pudo lanzar el intent.\nRevisa ContentProvider y stickers WebP 512×512.")


func _is_whatsapp_installed() -> bool:
	if tiktok_plugin and tiktok_plugin.has_method("isWhatsAppInstalled"):
		return bool(tiktok_plugin.isWhatsAppInstalled())
	return false

func _open_whatsapp_store() -> void:
	if tiktok_plugin and tiktok_plugin.has_method("openWhatsAppPlayStore"):
		tiktok_plugin.openWhatsAppPlayStore()
	else:
		_show_notice("Abre Google Play e instala WhatsApp (com.whatsapp).\nCon el plugin Android esto se abre solo.")


func _responsive_columns() -> int:
	var width := get_viewport_rect().size.x
	if width < 430.0:
		return 2
	if width < 720.0:
		return 3
	if width < 1050.0:
		return 4
	return 5

func _add_media_tile(parent: GridContainer, item: Dictionary, index: int, group: String) -> void:
	var card := Button.new()
	card.flat = true
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card.custom_minimum_size = Vector2(0, _fs(245))
	card.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	card.add_theme_stylebox_override("normal", _box(PANEL, 18, BORDER, 1))
	card.add_theme_stylebox_override("hover", _box(PANEL_2, 18, BLUE, 2))
	card.add_theme_stylebox_override("pressed", _box(Color("#1a2740"), 18, WHITE, 2))
	parent.add_child(card)

	var box := VBoxContainer.new()
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_theme_constant_override("separation", _fs(5))
	card.add_child(box)

	var cover := IconCanvas.new()
	cover.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cover.custom_minimum_size = Vector2(0, _fs(148))
	cover.mode = "shared" if group == "shared" else "tiktok"
	cover.index = index
	cover.bg_tint = PANEL_ICON
	box.add_child(cover)

	var title := Label.new()
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	title.text = str(item.get("title", "Vídeo"))
	title.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	title.add_theme_font_size_override("font_size", _fs(15))
	title.add_theme_color_override("font_color", WHITE)
	box.add_child(title)

	var user := Label.new()
	user.mouse_filter = Control.MOUSE_FILTER_IGNORE
	user.text = str(item.get("user", "@user"))
	user.add_theme_font_size_override("font_size", _fs(12))
	user.add_theme_color_override("font_color", MUTED)
	box.add_child(user)

	var key := _key(group, index)
	var badge := Label.new()
	badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	badge.text = "✓  SELECCIONADO" if selected.has(key) else "TOCA EL VÍDEO"
	badge.add_theme_font_size_override("font_size", _fs(12))
	badge.add_theme_color_override("font_color", WHITE if selected.has(key) else MUTED)
	badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(badge)
	card.button_down.connect(func(): _toggle_item(not selected.has(key), group, index, badge))

func _add_sticker_tile_tiktok(parent: GridContainer, item: Dictionary, index: int) -> void:
	_add_sticker_tile_generic(parent, item, index, "stickers", "TOCA EL STICKER")

func _add_sticker_tile(parent: GridContainer, item: Dictionary, index: int) -> void:
	_add_sticker_tile_generic(parent, item, index, "wa", "TOCA PARA SELECCIONAR")

func _add_sticker_tile_generic(parent: GridContainer, item: Dictionary, index: int, group: String, idle_text: String) -> void:
	var card := Button.new()
	card.flat = true
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card.custom_minimum_size = Vector2(0, _fs(230))
	card.add_theme_stylebox_override("normal", _box(PANEL, 18, BORDER, 1))
	card.add_theme_stylebox_override("hover", _box(PANEL_2, 18, GREEN if group == "wa" else BLUE, 2))
	card.add_theme_stylebox_override("pressed", _box(Color("#1a2740"), 18, WHITE, 2))
	parent.add_child(card)
	var box := VBoxContainer.new()
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_theme_constant_override("separation", _fs(5))
	card.add_child(box)
	var icon := IconCanvas.new()
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	icon.custom_minimum_size = Vector2(0, _fs(145))
	icon.mode = "sticker"
	icon.index = index
	icon.bg_tint = PANEL_ICON
	box.add_child(icon)
	var title := Label.new()
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	title.text = str(item.get("title", "Sticker"))
	title.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	title.add_theme_font_size_override("font_size", _fs(14))
	title.add_theme_color_override("font_color", WHITE)
	box.add_child(title)
	var key := _key(group, index)
	var badge := Label.new()
	badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	badge.text = "✓  SELECCIONADO" if selected.has(key) else idle_text
	badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	badge.add_theme_font_size_override("font_size", _fs(12))
	badge.add_theme_color_override("font_color", WHITE if selected.has(key) else MUTED)
	box.add_child(badge)
	card.button_down.connect(func(): _toggle_item(not selected.has(key), group, index, badge))

func _select_all_current_tiktok() -> void:
	var items := _current_tiktok_items()
	for i in range(items.size()):
		selected[_key(current_tiktok_tab, i)] = true
	_show_screen_preserve_selection("tiktok")

func _confirm_delete_current_tiktok() -> void:
	var count := _selected_count(current_tiktok_tab)
	if count == 0:
		_show_notice("Selecciona al menos un elemento de %s." % _tab_display_name(current_tiktok_tab))
		return
	var dialog := ConfirmationDialog.new()
	dialog.title = "Eliminar"
	dialog.dialog_text = "¿Eliminar %d elemento(s) de %s?" % [count, _tab_display_name(current_tiktok_tab)]
	_style_dialog(dialog)
	var ok_button := dialog.get_ok_button()
	if ok_button:
		ok_button.text = "Eliminar"
		ok_button.add_theme_color_override("font_color", WHITE)
		ok_button.add_theme_stylebox_override("normal", _box(RED, 16, WHITE, 1))
	var cancel_button := dialog.get_cancel_button()
	if cancel_button:
		cancel_button.text = "Cancelar"
		cancel_button.add_theme_stylebox_override("normal", _box(PANEL, 16, BORDER, 1))
	add_child(dialog)
	dialog.confirmed.connect(_delete_selected_current_tiktok)
	dialog.popup_centered()

func _delete_selected_current_tiktok() -> void:
	var indexes: Array[int] = []
	for key in selected.keys():
		var parts := str(key).split(":")
		if parts.size() == 2 and parts[0] == current_tiktok_tab:
			indexes.append(int(parts[1]))
	indexes.sort()
	indexes.reverse()
	var arr: Array = _current_tiktok_items()
	for idx in indexes:
		if idx >= 0 and idx < arr.size():
			arr.remove_at(idx)
	match current_tiktok_tab:
		"shared":
			shared = arr
		"stickers":
			tiktok_stickers = arr
		_:
			favorites = arr
	for key in selected.keys().duplicate():
		if str(key).begins_with(current_tiktok_tab + ":"):
			selected.erase(key)
	_save_local_state()
	_show_screen_preserve_selection("tiktok")
	_show_notice("Elementos eliminados correctamente.")

func _show_screen_preserve_selection(screen: String) -> void:
	current_screen = screen
	_clear_content()
	if screen == "tiktok":
		_tiktok_screen()
	elif screen == "whatsapp":
		_whatsapp_screen()
	_update_status()

func _selected_count(group: String) -> int:
	var total := 0
	for key in selected.keys():
		if str(key).begins_with(group + ":"):
			total += 1
	return total

func _key(group: String, index: int) -> String:
	return group + ":" + str(index)

func _toggle_item(on: bool, group: String, index: int, badge: Label = null) -> void:
	var key := _key(group, index)
	if on:
		selected[key] = true
	else:
		selected.erase(key)
	if is_instance_valid(badge):
		var idle := "TOCA PARA SELECCIONAR" if group == "wa" else ("TOCA EL STICKER" if group == "stickers" else "TOCA EL VÍDEO")
		badge.text = "✓  SELECCIONADO" if on else idle
		badge.add_theme_color_override("font_color", WHITE if on else MUTED)
	_update_status()

func _update_status() -> void:
	if not is_instance_valid(status_label):
		return
	var n := 0
	if current_screen == "tiktok":
		n = _selected_count(current_tiktok_tab)
	elif current_screen == "whatsapp":
		n = _selected_count("wa")
	var tt := "TT○"
	match tiktok_status:
		"conectado":
			tt = "TT✓"
		"conectando":
			tt = "TT…"
		"error":
			tt = "TT!"
	status_label.text = "V4.6.2 · %s · sel %d" % [tt, n]


func _section_title(title: String, sub: String) -> void:
	var t := Label.new()
	t.text = title
	t.add_theme_font_size_override("font_size", _fs(26))
	t.add_theme_color_override("font_color", WHITE)
	content_box.add_child(t)
	var s := Label.new()
	s.text = sub
	s.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	s.add_theme_font_size_override("font_size", _fs(15))
	s.add_theme_color_override("font_color", MUTED)
	content_box.add_child(s)

func _make_big_card(icon: String, title: String, desc: String) -> PanelContainer:
	var p := PanelContainer.new()
	p.custom_minimum_size = Vector2(0, _fs(132))
	p.add_theme_stylebox_override("panel", _box(PANEL, 22, BORDER, 1))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", _fs(14))
	p.add_child(row)
	# Icon zone with blue background
	var icon_panel := PanelContainer.new()
	icon_panel.custom_minimum_size = Vector2(_fs(74), _fs(74))
	icon_panel.add_theme_stylebox_override("panel", _box(PANEL_ICON, 18, BORDER, 1))
	var ic := Label.new()
	ic.text = icon
	ic.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ic.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	ic.add_theme_font_size_override("font_size", _fs(34))
	ic.add_theme_color_override("font_color", WHITE)
	icon_panel.add_child(ic)
	row.add_child(icon_panel)
	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", _fs(4))
	row.add_child(box)
	var t := Label.new()
	t.text = title
	t.add_theme_font_size_override("font_size", _fs(19))
	t.add_theme_color_override("font_color", WHITE)
	box.add_child(t)
	var d := Label.new()
	d.text = desc
	d.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	d.add_theme_font_size_override("font_size", _fs(14))
	d.add_theme_color_override("font_color", MUTED)
	box.add_child(d)
	return p

func _make_button(text: String, fill: Color) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_size_override("font_size", _fs(15))
	b.add_theme_color_override("font_color", WHITE)
	b.custom_minimum_size = Vector2(0, _fs(52))
	b.add_theme_stylebox_override("normal", _box(fill, 18, BORDER, 1))
	b.add_theme_stylebox_override("hover", _box(fill.lightened(0.10), 18, WHITE, 1))
	b.add_theme_stylebox_override("pressed", _box(fill.darkened(0.10), 18, WHITE, 2))
	return b

func _box(fill: Color, radius: int, border_color: Color, border_width: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = fill
	s.border_color = border_color
	s.set_border_width_all(border_width)
	s.set_corner_radius_all(radius)
	s.content_margin_left = _fs(10)
	s.content_margin_right = _fs(10)
	s.content_margin_top = _fs(7)
	s.content_margin_bottom = _fs(7)
	return s

func _style_dialog(dialog: Window) -> void:
	var scale := _ui_scale()
	dialog.min_size = Vector2(clamp(get_viewport_rect().size.x * 0.88, 320, 900), 360.0 * scale)
	dialog.add_theme_font_size_override("font_size", int(round(18.0 * scale)))
	dialog.add_theme_color_override("font_color", WHITE)
	dialog.add_theme_color_override("title_color", WHITE)
	if dialog is AcceptDialog or dialog is ConfirmationDialog:
		dialog.add_theme_stylebox_override("panel", _box(Color("#0f1a2e"), 28, BLUE, 3))
		var label = dialog.get_label() if dialog.has_method("get_label") else null
		if is_instance_valid(label):
			label.add_theme_font_size_override("font_size", int(round(18.0 * scale)))
			label.add_theme_color_override("font_color", WHITE)
			label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

func _show_notice(message: String) -> void:
	var dialog := AcceptDialog.new()
	dialog.title = "StickerGo"
	dialog.dialog_text = message
	dialog.ok_button_text = "✓  OK"
	_style_dialog(dialog)
	var scale := _ui_scale()
	# Ensure dialog is tall enough for long text + OK button
	var lines := message.count("\n") + 1
	var h: float = clampf(280.0 * scale + float(lines) * 28.0 * scale, 360.0 * scale, get_viewport_rect().size.y * 0.75)
	dialog.min_size = Vector2(clamp(get_viewport_rect().size.x * 0.9, 300, 920), h)
	add_child(dialog)
	var ok := dialog.get_ok_button()
	if is_instance_valid(ok):
		ok.text = "✓  OK"
		ok.custom_minimum_size = Vector2(200.0 * scale, 64.0 * scale)
		ok.add_theme_font_size_override("font_size", int(round(18.0 * scale)))
		ok.add_theme_color_override("font_color", WHITE)
		ok.add_theme_stylebox_override("normal", _box(PINK, 20, Color("#fb7185"), 2))
		ok.add_theme_stylebox_override("hover", _box(Color("#f43f5e"), 20, WHITE, 2))
		ok.add_theme_stylebox_override("pressed", _box(Color("#be123c"), 20, WHITE, 3))
	dialog.popup_centered()


class IconCanvas:
	extends Control
	var mode: String = "tiktok"
	var index: int = 0
	var bg_tint: Color = Color("#12304a")

	func _ready() -> void:
		queue_redraw()

	func _draw() -> void:
		var r := minf(size.x, size.y) * 0.38
		var center := Rect2(Vector2.ZERO, size).get_center()
		var base_colors := [
			Color("#3b82f6"), Color("#e11d48"), Color("#10b981"),
			Color("#6366f1"), Color("#f59e0b"), Color("#06b6d4")
		]
		var c: Color = base_colors[index % base_colors.size()]
		draw_rect(Rect2(0, 0, size.x, size.y), bg_tint)
		draw_circle(center, r, c)
		draw_circle(center + Vector2(r * 0.08, r * 0.08), r * 0.72, Color("#0b1220"))
		if mode == "sticker":
			draw_circle(center, r * 0.56, Color("#fde68a"))
			draw_circle(center + Vector2(-r * 0.18, -r * 0.10), r * 0.08, Color("#0f172a"))
			draw_circle(center + Vector2(r * 0.18, -r * 0.10), r * 0.08, Color("#0f172a"))
			draw_arc(center + Vector2(0, r * 0.05), r * 0.22, 0.2, 2.9, 24, Color("#0f172a"), maxf(3.0, r * 0.045))
		else:
			var p1 := center + Vector2(-r * 0.35, -r * 0.48)
			var p2 := center + Vector2(r * 0.48, 0)
			var p3 := center + Vector2(-r * 0.35, r * 0.48)
			draw_colored_polygon(PackedVector2Array([p1, p2, p3]), Color("#ffffff"))
			draw_circle(center + Vector2(r * 0.46, r * 0.46), r * 0.20, Color("#10b981"))
			draw_circle(center + Vector2(r * 0.46, r * 0.46), r * 0.12, Color("#ffffff"))
