StickerGo — Build del plugin Android (AAR) para StickerGoTikTok

Estado actual
-------------
El puente nativo de TikTok (android/plugin) SÍ se compila a un AAR real y
SÍ se empaqueta en la APK al exportar, siempre que:

1. El AAR se haya construido (localmente o vía GitHub Actions).
2. Los archivos resultantes existan en:
   addons/StickerGoTikTok/bin/release/StickerGoTikTok-release.aar
   addons/StickerGoTikTok/bin/debug/StickerGoTikTok-debug.aar
3. El addon "StickerGoTikTok" esté habilitado en Godot (ya lo está, ver
   project.godot -> [editor_plugins]).

Requisitos de entorno (fijados el 2026-09 tras revisar compatibilidad AGP)
---------------------------------------------------------------------------
- JDK 17
- Gradle 8.11.1 o superior
- Android Gradle Plugin (AGP) 8.10.1 o superior
- compileSdk 36 instalado en el SDK de Android usado para compilar

Importante: AGP 8.7.x (usado antes) solo soporta oficialmente hasta
compileSdk 35. Con compileSdk = 36 hace falta AGP 8.10.0+, y AGP 8.10.0+
exige Gradle 8.11.1 como minimo. Por eso el proyecto ya no puede compilarse
con Gradle 8.9: no es un capricho, es un requisito de compatibilidad de
Google documentado en las release notes de AGP.

Build local
-----------
cd android/plugin
gradle :plugin:copyReleaseAAR :plugin:copyDebugAAR

Esto compila assembleRelease/assembleDebug (como dependencia automatica) y
copia los .aar ya con el nombre correcto directamente a
addons/StickerGoTikTok/bin/release y .../bin/debug.

Build en GitHub Actions
------------------------
El workflow .github/workflows/build-stickergo-aar.yml hace exactamente lo
mismo de forma reproducible: instala JDK 17, instala la plataforma Android
36 via sdkmanager, usa Gradle 8.11.1, y ejecuta las mismas tareas Gradle de
copia (no hay ningun "cp" manual con nombres de archivo hardcodeados que
puedan desincronizarse del nombre real generado por Gradle).

Notas de seguridad
-------------------
- TikTokConfig.kt contiene solo el Client Key (publico). El Client Secret
  de TikTok NUNCA debe copiarse aqui ni a ningun archivo del repositorio:
  vive unicamente en tu backend, donde se intercambia el authorization code
  por un access token.
- El AAR no contiene ningun secreto embebido.
