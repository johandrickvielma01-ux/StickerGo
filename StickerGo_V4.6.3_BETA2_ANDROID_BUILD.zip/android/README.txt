StickerGo V4.6.2 — Android plugin

Objetivo
--------
Puente Android para:
- TikTok Login Kit oficial.
- Detección de TikTok/WhatsApp.
- Lanzamiento del flujo oficial de añadir sticker pack a WhatsApp.

TikTok
------
El SDK oficial se declara como dependencia Gradle/Maven en:
android/plugin/plugin/build.gradle.kts

Repositorio:
https://artifact.bytedance.com/repository/AwemeOpenSDK

No hace falta descargar manualmente el SDK de TikTok como .aar.
El puente StickerGo sigue siendo una librería Android para que Godot pueda cargar el plugin.

Configuración
-------------
Edita:
android/plugin/plugin/src/main/java/com/stickergo/tiktok/TikTokConfig.kt

Necesitas:
- Client Key de TikTok.
- Redirect URI HTTPS registrado en TikTok.

Nunca pongas Client Secret dentro de la APK.

WhatsApp
--------
El flujo usa:
com.whatsapp.intent.action.ENABLE_STICKER_PACK

Para packs reales se necesita un ContentProvider con autoridad:
${applicationId}.stickercontentprovider

Y stickers WebP 512×512, 3–30 por pack, sin mezclar static/animated.

Prueba recomendada
------------------
1. Preparar el entorno Android/Gradle de Godot.
2. Compilar el plugin Android.
3. Activar el plugin en el proyecto.
4. Exportar una APK de desarrollo.
5. Probar primero el botón de conexión TikTok.
6. Probar después el flujo de packs de WhatsApp.

No necesitas usar Android Studio para programar StickerGo; solo usa el entorno de compilación
que tu versión de Godot soporte.
