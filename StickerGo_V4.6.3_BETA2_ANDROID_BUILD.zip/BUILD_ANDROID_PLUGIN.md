StickerGo V4.6.2 — Android plugin build notes

Current export fix:
- TikTok OpenSDK dependencies use version 2.4.0 consistently.
- The missing StickerGoTikTok-debug.aar reference was removed from the Godot export plugin, so Gradle no longer fails because that file is absent.
- The official TikTok Maven repository remains configured.

Important:
This build-fix ZIP is intended to get the Android APK export past the missing-AAR error. The custom Kotlin bridge is NOT packaged into the APK by this export configuration, so the native TikTok login bridge is not active yet.

The Kotlin bridge project remains under android/plugin/ and can be built into an AAR later.
