package com.stickergo.tiktok

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.view.View

import com.tiktok.open.sdk.auth.AuthApi
import com.tiktok.open.sdk.auth.AuthRequest
import com.tiktok.open.sdk.auth.utils.PKCEUtils

import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.SignalInfo
import org.godotengine.godot.plugin.UsedByGodot

/**
 * StickerGo Android bridge for the official TikTok Login Kit and WhatsApp
 * sticker-pack handoff.
 *
 * IMPORTANT:
 * - The TikTok client secret is never stored in this APK/plugin.
 * - The authorization code and PKCE code_verifier must be exchanged for
 *   tokens by a secure server-side backend.
 */
class StickerGoTikTokPlugin(godot: Godot) : GodotPlugin(godot) {

    companion object {
        val AUTH_SUCCESS = SignalInfo(
            "tiktok_auth_success",
            String::class.java, // authorization code
            String::class.java  // granted permissions
        )

        val AUTH_ERROR = SignalInfo(
            "tiktok_auth_error",
            String::class.java
        )

        val AUTH_STARTED = SignalInfo(
            "tiktok_auth_started",
            String::class.java // TikTokApp or ChromeTab
        )

        private const val WA_PACKAGE = "com.whatsapp"
        private const val WA_BUSINESS_PACKAGE = "com.whatsapp.w4b"

        private const val TIKTOK_MUSICAL_LY = "com.zhiliaoapp.musically"
        private const val TIKTOK_TRILL = "com.ss.android.ugc.trill"

        private const val ACTION_ENABLE_STICKER_PACK =
            "com.whatsapp.intent.action.ENABLE_STICKER_PACK"
    }

    private var authApi: AuthApi? = null
    private var codeVerifier: String = ""
    private var lastAuthMethod: String = ""
    private var lastHandledCallbackUri: String = ""

    override fun getPluginName(): String {
        return BuildConfig.GODOT_PLUGIN_NAME
    }

    override fun getPluginSignals(): Set<SignalInfo> {
        return setOf(
            AUTH_SUCCESS,
            AUTH_ERROR,
            AUTH_STARTED
        )
    }

    // -------------------------------------------------------------------------
    // Configuration
    // -------------------------------------------------------------------------

    @UsedByGodot
    fun isConfigured(): Boolean {
        return TikTokConfig.CLIENT_KEY.isNotBlank() &&
            TikTokConfig.CLIENT_KEY != "REPLACE_WITH_TIKTOK_CLIENT_KEY" &&
            TikTokConfig.REDIRECT_URI.startsWith("https://") &&
            !TikTokConfig.REDIRECT_URI.contains("YOUR-DOMAIN")
    }

    // -------------------------------------------------------------------------
    // Installed-app checks
    // -------------------------------------------------------------------------

    @UsedByGodot
    fun isTikTokInstalled(): Boolean {
        return isPackageInstalled(TIKTOK_MUSICAL_LY) ||
            isPackageInstalled(TIKTOK_TRILL)
    }

    @UsedByGodot
    fun isWhatsAppInstalled(): Boolean {
        return isPackageInstalled(WA_PACKAGE) ||
            isPackageInstalled(WA_BUSINESS_PACKAGE)
    }

    // -------------------------------------------------------------------------
    // PKCE
    // -------------------------------------------------------------------------

    /**
     * Returns the verifier generated for the current login request.
     * The backend needs this value together with the authorization code.
     */
    @UsedByGodot
    fun getCodeVerifier(): String {
        return codeVerifier
    }

    // -------------------------------------------------------------------------
    // TikTok Login
    // -------------------------------------------------------------------------

    /**
     * Starts TikTok Login Kit.
     *
     * If TikTok is installed, use the TikTok app flow. Otherwise use the
     * Chrome Custom Tab/browser flow.
     */
    @UsedByGodot
    fun startLogin() {
        runOnHostThread {
            if (!isConfigured()) {
                emitSignal(
                    AUTH_ERROR.name,
                    "TikTok no está configurado. Revisa TikTokConfig.kt."
                )
                return@runOnHostThread
            }

            try {
                val act = activity
                if (act == null) {
                    emitSignal(
                        AUTH_ERROR.name,
                        "Actividad Android no disponible."
                    )
                    return@runOnHostThread
                }

                authApi = AuthApi(act)
                codeVerifier = PKCEUtils.generateCodeVerifier()

                val request = AuthRequest(
                    clientKey = TikTokConfig.CLIENT_KEY,
                    scope = TikTokConfig.BASIC_SCOPE,
                    redirectUri = TikTokConfig.REDIRECT_URI,
                    codeVerifier = codeVerifier
                )

                val method = if (isTikTokInstalled()) {
                    AuthApi.AuthMethod.TikTokApp
                } else {
                    AuthApi.AuthMethod.ChromeTab
                }

                lastAuthMethod = if (method == AuthApi.AuthMethod.TikTokApp) {
                    "TikTokApp"
                } else {
                    "ChromeTab"
                }

                emitSignal(
                    AUTH_STARTED.name,
                    lastAuthMethod
                )

                authApi?.authorize(
                    request = request,
                    authMethod = method
                )
            } catch (e: Exception) {
                emitSignal(
                    AUTH_ERROR.name,
                    e.message ?: "No se pudo iniciar el login de TikTok."
                )
            }
        }
    }

    /** Forces the Chrome Custom Tab/browser flow for testing. */
    @UsedByGodot
    fun startLoginInBrowser() {
        runOnHostThread {
            if (!isConfigured()) {
                emitSignal(
                    AUTH_ERROR.name,
                    "TikTok no está configurado. Revisa TikTokConfig.kt."
                )
                return@runOnHostThread
            }

            try {
                val act = activity
                if (act == null) {
                    emitSignal(
                        AUTH_ERROR.name,
                        "Actividad Android no disponible."
                    )
                    return@runOnHostThread
                }

                authApi = AuthApi(act)
                codeVerifier = PKCEUtils.generateCodeVerifier()

                val request = AuthRequest(
                    clientKey = TikTokConfig.CLIENT_KEY,
                    scope = TikTokConfig.BASIC_SCOPE,
                    redirectUri = TikTokConfig.REDIRECT_URI,
                    codeVerifier = codeVerifier
                )

                lastAuthMethod = "ChromeTab"
                emitSignal(
                    AUTH_STARTED.name,
                    lastAuthMethod
                )

                authApi?.authorize(
                    request = request,
                    authMethod = AuthApi.AuthMethod.ChromeTab
                )
            } catch (e: Exception) {
                emitSignal(
                    AUTH_ERROR.name,
                    e.message ?: "Error abriendo el navegador para TikTok."
                )
            }
        }
    }

    // -------------------------------------------------------------------------
    // Godot 4 Android lifecycle
    // -------------------------------------------------------------------------

    /**
     * Godot 4.x Android plugin lifecycle callback.
     * The View? return type is required by the current GodotPlugin API.
     */
    override fun onMainCreate(activity: Activity?): View? {
        if (activity != null) {
            authApi = AuthApi(activity)
            handleCallbackIntent(activity.intent)
        }

        return super.onMainCreate(activity)
    }

    /**
     * Browser/App Link callbacks can arrive while the existing Godot activity
     * is being resumed instead of through onMainActivityResult(). Handle the
     * redirect here as well, but only when the intent actually matches our
     * TikTok callback URI.
     */
    override fun onMainResume() {
        super.onMainResume()
        handleCallbackIntent(activity?.intent)
    }

    /**
     * TikTokApp can return through startActivityForResult().
     */
    override fun onMainActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onMainActivityResult(
            requestCode,
            resultCode,
            data
        )

        if (data != null) {
            handleIntent(data)
        }
    }

    // -------------------------------------------------------------------------
    // TikTok callback
    // -------------------------------------------------------------------------

    /**
     * Handles a TikTok callback only when the activity intent is an Android
     * VIEW intent matching the exact HTTPS redirect URI. This prevents normal
     * launcher/resume intents from being sent to TikTok's callback parser.
     */
    private fun handleCallbackIntent(intent: Intent?) {
        if (intent == null || intent.action != Intent.ACTION_VIEW) {
            return
        }

        val uri = intent.data ?: return
        val expected = Uri.parse(TikTokConfig.REDIRECT_URI)

        if (uri.scheme != expected.scheme ||
            uri.host != expected.host ||
            uri.path != expected.path) {
            return
        }

        val callbackUri = uri.toString()
        if (callbackUri == lastHandledCallbackUri) {
            return
        }

        if (handleIntent(intent)) {
            lastHandledCallbackUri = callbackUri
        }
    }

    /**
     * Parses a TikTok intent. Returns true only when TikTok returned a response,
     * so the same browser callback is not emitted repeatedly on resume.
     */
    private fun handleIntent(intent: Intent): Boolean {
        try {
            val act = activity
            if (act == null) {
                emitSignal(
                    AUTH_ERROR.name,
                    "Actividad Android no disponible para procesar el callback."
                )
                return false
            }

            val api = authApi ?: AuthApi(act).also {
                authApi = it
            }

            val response = api.getAuthResponseFromIntent(
                intent,
                TikTokConfig.REDIRECT_URI
            ) ?: return false

            if (response.authCode.isNotEmpty()) {
                emitSignal(
                    AUTH_SUCCESS.name,
                    response.authCode,
                    response.grantedPermissions.toString()
                )
                return true
            }

            // Do not use the old/nonexistent authMsg property. The current
            // response exposes authErrorDescription and errorMsg.
            val description =
                response.authErrorDescription
                    ?: response.errorMsg
                    ?: "TikTok rechazó la autorización."

            emitSignal(
                AUTH_ERROR.name,
                description
            )
            return true
        } catch (e: Exception) {
            emitSignal(
                AUTH_ERROR.name,
                e.message ?: "Error procesando el callback de TikTok."
            )
            return false
        }
    }

    // -------------------------------------------------------------------------
    // WhatsApp
    // -------------------------------------------------------------------------

    /**
     * Opens WhatsApp's official sticker-pack confirmation UI.
     *
     * The app must provide a valid Sticker ContentProvider for the supplied
     * authority and pack identifier before WhatsApp can actually import it.
     */
    @UsedByGodot
    fun addStickerPackToWhatsApp(
        authority: String,
        identifier: String,
        packName: String
    ): Boolean {
        val act = activity ?: return false

        if (!isWhatsAppInstalled()) {
            return false
        }

        return try {
            val whatsappPackage = if (isPackageInstalled(WA_PACKAGE)) {
                WA_PACKAGE
            } else {
                WA_BUSINESS_PACKAGE
            }

            val intent = Intent().apply {
                action = ACTION_ENABLE_STICKER_PACK
                putExtra("sticker_pack_id", identifier)
                putExtra("sticker_pack_authority", authority)
                putExtra("sticker_pack_name", packName)
                setPackage(whatsappPackage)
            }

            act.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    /** Opens WhatsApp's Play Store page when available. */
    @UsedByGodot
    fun openWhatsAppPlayStore() {
        val act = activity ?: return

        try {
            act.startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=$WA_PACKAGE")
                )
            )
        } catch (_: Exception) {
            try {
                act.startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse(
                            "https://play.google.com/store/apps/details?id=$WA_PACKAGE"
                        )
                    )
                )
            } catch (_: Exception) {
                // Nothing else to do.
            }
        }
    }

    // -------------------------------------------------------------------------
    // Package helper
    // -------------------------------------------------------------------------

    private fun isPackageInstalled(packageName: String): Boolean {
        val ctx = activity?.applicationContext ?: return false

        return try {
            ctx.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }
}
