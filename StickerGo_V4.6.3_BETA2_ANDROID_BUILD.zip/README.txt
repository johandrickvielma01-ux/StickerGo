StickerGo V4.6.2

Novedades
---------
- Mantiene la galería TikTok por fechas: Favoritos / Compartidos / Stickers.
- Orden por más recientes / más viejos.
- Carga por partes al hacer scroll.
- Selección por toque en toda la tarjeta.
- Packs de 3–30 stickers.
- Integración preparada con WhatsApp mediante el flujo oficial de sticker packs.
- Diagnóstico de conexiones desde Ajustes.
- Estado local migrado a stickergo_v462.json.
- UI responsive para teléfonos y tablets.
- Mensajes de configuración más claros.

TikTok
------
La conexión real usa el Login Kit oficial de TikTok mediante el plugin Android.
No se usan contraseñas, cookies, scraping ni acceso a almacenamiento privado.
Los scopes adicionales dependen de los permisos aprobados por TikTok.

Importante sobre Android Studio / AAR
------------------------------------
StickerGo no requiere que programes la aplicación dentro de Android Studio.
La parte Android nativa se compila con Gradle/Godot cuando el entorno Android está preparado.
El plugin nativo de Godot se empaqueta como librería Android; el proyecto incluye su código fuente y
las dependencias oficiales de TikTok por Maven. Si tu flujo de Godot requiere un AAR precompilado,
ese AAR se genera a partir del plugin, no es el SDK de TikTok descargado manualmente.

WhatsApp
--------
StickerGo no inicia sesión con número de teléfono ni solicita códigos.
El flujo previsto es: crear/validar un pack -> abrir el intent oficial de WhatsApp ->
WhatsApp muestra su confirmación -> el usuario acepta.
Para un pack real: WebP 512×512, 3–30 stickers y ContentProvider compatible.

Estado
------
V4.6.2 es una versión de preparación y pruebas de integración.
La pantalla puede funcionar sin conexión real; la sincronización de datos privados de TikTok
solo debe implementarse con APIs/scopes oficialmente disponibles.


V4.6.2 BUILD FIX: TikTok OpenSDK 2.4.0 is used consistently. The missing custom StickerGoTikTok-debug.aar export reference was removed so Android Gradle export can proceed without that absent file. The native Kotlin TikTok bridge is not active in this build-fix APK until its AAR is built and injected.
