# StickerGo V4 REAL — Configuración de TikTok

## 1. Crear la app de TikTok

Entra en TikTok for Developers y crea una aplicación.

Añade:
- Login Kit
- Webhooks si vas a usar Data Portability con notificaciones
- Data Portability API cuando quieras pedir datos de actividad

Para Login Kit Android TikTok pide:
- client key
- client secret (solo servidor)
- Android package
- MD5
- SHA-256
- redirect URI HTTPS

## 2. Package name

StickerGo usa:

com.stickergo.app

Si quieres cambiarlo, cambia el applicationId/package de la integración antes de registrar la app en TikTok.

## 3. Client key

Edita:

android/plugin/src/main/java/com/stickergo/tiktok/TikTokConfig.kt

y coloca únicamente el client key.

NO coloques client_secret en Godot ni en Kotlin de la APK.

## 4. Redirect URI

TikTok requiere un redirect URI HTTPS autorizado.

Ejemplo:

https://tu-dominio.com/tiktok/callback

Debe coincidir exactamente con el configurado en TikTok.

## 5. Certificados Android

Cuando exportes StickerGo, necesitas registrar en TikTok los fingerprints del certificado que realmente firma la app.

Para una build local puedes obtenerlos con keytool/Gradle.
Para Google Play, usa los fingerprints del certificado de App Signing de Play Console.

## 6. Godot

Esta integración utiliza el sistema Android plugin v2 de Godot 4.2+.

En Godot:

Project
→ Install Android Build Template

Luego:

Project
→ Export
→ Android
→ Gradle Build
→ Use Gradle Build = ON

El plugin se integra como librería Android durante el build.

## 7. Prueba

Instala TikTok en el teléfono.

Abre StickerGo.
Ve a TikTok.
Pulsa:

Conectar TikTok

Debe abrirse el flujo oficial de autorización.

Después de aceptar:
- StickerGo recibe el callback.
- Se emite el authorization code.
- La app muestra que TikTok fue autorizado.

## 8. Token

El authorization code debe intercambiarse en tu servidor por un access token.
El client secret debe vivir únicamente en el servidor.

TikTok recomienda gestionar los tokens en servidor.

## 9. Datos reales

Para mostrar vídeos públicos propios, TikTok documenta el scope:

video.list

Para Favorite Videos / Share History se debe utilizar la vía de Data Portability correspondiente y conseguir la aprobación de TikTok para los scopes necesarios.

No implementamos scraping ni lectura de almacenamiento privado de TikTok.

## 10. WhatsApp

StickerGo puede generar packs compatibles y lanzar el flujo oficial "Add to WhatsApp".

No se solicitan códigos ni contraseñas de WhatsApp.

## V4.6.2 SDK fix
V4.6.2 now pins the TikTok OpenSDK Android dependencies to **2.4.0**. The previous 2.3.1 pin was invalid for the `tiktok-open-sdk-auth` artifact and caused Gradle resolution to fail.

The TikTok Maven repository remains:
`https://artifact.bytedance.com/repository/AwemeOpenSDK`

If TikTok changes the published version again, update all TikTok OpenSDK modules together rather than mixing versions.
