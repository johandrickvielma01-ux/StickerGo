# StickerGo V4.6.3 BETA 2 — Android-only build route

This package prepares the TikTok Android plugin for remote Gradle compilation.
The project is designed for Godot 4.7.2. The native bridge is built as an AAR, then placed under `addons/StickerGoTikTok/bin/`.

## Why this exists

The previous BETA exported an APK without the native bridge AAR, so the app reported that the Android plugin was not loaded. Godot's v2 Android plugin system expects the AAR to be returned by `_get_android_libraries()`.

## Build without a PC

A GitHub Actions workflow is included at `.github/workflows/build-stickergo-aar.yml`. It builds the AAR on a GitHub-hosted runner using JDK 17 and Gradle 8.9, then uploads the ready project as an artifact.

No TikTok client secret is used or stored by this workflow.

## After the workflow finishes

Download the artifact named `StickerGo-V4.6.3-BETA2-READY`. It contains the compiled AAR inside the addon. Open that project in Godot 4.7.2 Android, keep Gradle Build enabled, and export using the same signing key whose SHA-256 is registered in TikTok.
