package com.stickergo.tiktok

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri

import com.tiktok.open.sdk.auth.AuthApi
import com.tiktok.open.sdk.auth.model.AuthRequest
import com.tiktok.open.sdk.auth.utils.PKCEUtils

import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.SignalInfo
import org.godotengine.godot.plugin.UsedByGodot

/**
 * Official TikTok Login Kit + WhatsApp sticker helpers for StickerGo.
 * Never stores client_secret. Authorization code must be exchanged on a server.
 */
class StickerGoTikTokPlugin(godot: Godot) : GodotPlugin(godot) {

    companion object {
        val AUTH_SUCCESS = SignalInfo(
            "tiktok_auth_success",
            String::class.java, // auth code
            String::class.java  // granted permissions
        )
        val AUTH_ERROR = SignalInfo(
            "tiktok_auth_error",
            String::class.java
        )
        val AUTH_STARTED = SignalInfo(
            "tiktok_auth_started",
            String::class.java // method used: TikTokApp | ChromeTab
        )

        private const val WA_PACKAGE = "com.whatsapp"
        private const val WA_BUSINESS_PACKAGE = "com.whatsapp.w4b"
        private const val TIKTOK_MUSICAL_LY = "com.zhiliaoapp.musically"
        private const val TIKTOK_TRILL = "com.ss.android.ugc.trill"
        // Official WhatsApp sticker pack enable action
        private const val ACTION_ENABLE_STICKER_PACK = "com.whatsapp.intent.action.ENABLE_STICKER_PACK"
    }

    private var authApi: AuthApi? = null
    private var codeVerifier: String = ""
    private var lastAuthMethod: String = ""

    override fun getPluginName(): String = BuildConfig.GODOT_PLUGIN_NAME

    override fun getPluginSignals(): Set<SignalInfo> =
        setOf(AUTH_SUCCESS, AUTH_ERROR, AUTH_STARTED)

    @UsedByGodot
    fun isConfigured(): Boolean {
        return TikTokConfig.CLIENT_KEY != "REPLACE_WITH_TIKTOK_CLIENT_KEY" &&
            TikTokConfig.REDIRECT_URI.startsWith("https://") &&
            !TikTokConfig.REDIRECT_URI.contains("YOUR-DOMAIN")
    }

    @UsedByGodot
    fun isTikTokInstalled(): Boolean {
        return isPackageInstalled(TIKTOK_MUSICAL_LY) || isPackageInstalled(TIKTOK_TRILL)
    }

    @UsedByGodot
    fun isWhatsAppInstalled(): Boolean {
        return isPackageInstalled(WA_PACKAGE) || isPackageInstalled(WA_BUSINESS_PACKAGE)
    }

    @UsedByGodot
    fun getCodeVerifier(): String = codeVerifier

    /**
     * Starts official OAuth. Prefers TikTok app; falls back to Chrome Custom Tab
     * when the TikTok app is not installed (AuthMethod.ChromeTab).
     */
    @UsedByGodot
    fun startLogin() {
        runOnHostThread {
            if (!isConfigured()) {
                emitSignal(
                    AUTH_ERROR.name,
                    "TikTok no está configurado. Completa TikTokConfig.kt con client key y redirect HTTPS."
                )
                return@runOnHostThread
            }

            try {
                val act = activity ?: run {
                    emitSignal(AUTH_ERROR.name, "Actividad Android no disponible.")
                    return@runOnHostThread
                }
                authApi = AuthApi(act)
                codeVerifier = PKCEUtils.generateCodeVerifier()

                val request = AuthRequest(
                    TikTokConfig.CLIENT_KEY,
                    TikTokConfig.BASIC_SCOPE,
                    TikTokConfig.REDIRECT_URI,
                    codeVerifier
                )

                val method = if (isTikTokInstalled()) {
                    AuthApi.AuthMethod.TikTokApp
                } else {
                    AuthApi.AuthMethod.ChromeTab
                }
                lastAuthMethod = if (method == AuthApi.AuthMethod.TikTokApp) "TikTokApp" else "ChromeTab"
                emitSignal(AUTH_STARTED.name, lastAuthMethod)

                authApi?.authorize(request, method)
            } catch (e: Exception) {
                emitSignal(
                    AUTH_ERROR.name,
                    e.message ?: "No se pudo iniciar el login oficial de TikTok."
                )
            }
        }
    }

    /**
     * Force browser/ChromeTab flow (useful for testing without TikTok app).
     */
    @UsedByGodot
    fun startLoginInBrowser() {
        runOnHostThread {
            if (!isConfigured()) {
                emitSignal(
                    AUTH_ERROR.name,
                    "TikTok no está configurado. Completa TikTokConfig.kt."
                )
                return@runOnHostThread
            }
            try {
                val act = activity ?: run {
                    emitSignal(AUTH_ERROR.name, "Actividad Android no disponible.")
                    return@runOnHostThread
                }
                authApi = AuthApi(act)
                codeVerifier = PKCEUtils.generateCodeVerifier()
                val request = AuthRequest(
                    TikTokConfig.CLIENT_KEY,
                    TikTokConfig.BASIC_SCOPE,
                    TikTokConfig.REDIRECT_URI,
                    codeVerifier
                )
                lastAuthMethod = "ChromeTab"
                emitSignal(AUTH_STARTED.name, lastAuthMethod)
                authApi?.authorize(request, AuthApi.AuthMethod.ChromeTab)
            } catch (e: Exception) {
                emitSignal(AUTH_ERROR.name, e.message ?: "Error abriendo ChromeTab.")
            }
        }
    }

    /**
     * Launches the official WhatsApp "Add sticker pack" confirmation UI.
     * Requires a ContentProvider already registered that serves the pack
     * (see android/README and WhatsApp sample sticker app).
     *
     * @param authority ContentProvider authority (must start with package name)
     * @param identifier Unique pack id
     * @param packName Display name shown in WhatsApp
     */
    @UsedByGodot
    fun addStickerPackToWhatsApp(authority: String, identifier: String, packName: String): Boolean {
        val act = activity ?: return false
        if (!isWhatsAppInstalled()) {
            return false
        }
        return try {
            val intent = Intent().apply {
                action = ACTION_ENABLE_STICKER_PACK
                putExtra("sticker_pack_id", identifier)
                putExtra("sticker_pack_authority", authority)
                putExtra("sticker_pack_name", packName)
                setPackage(
                    if (isPackageInstalled(WA_PACKAGE)) WA_PACKAGE else WA_BUSINESS_PACKAGE
                )
            }
            act.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    @UsedByGodot
    fun openWhatsAppPlayStore() {
        val act = activity ?: return
        try {
            act.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$WA_PACKAGE"))
            )
        } catch (_: Exception) {
            act.startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=$WA_PACKAGE")
                )
            )
        }
    }

    override fun onMainCreate(activity: android.app.Activity) {
        super.onMainCreate(activity)
        authApi = AuthApi(activity)
        handleIntent(activity.intent)
    }

    override fun onMainActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onMainActivityResult(requestCode, resultCode, data)
        data?.let { handleIntent(it) }
    }

    override fun onMainNewIntent(intent: Intent?) {
        super.onMainNewIntent(intent)
        intent?.let { handleIntent(it) }
    }

    private fun handleIntent(intent: Intent) {
        val api = authApi ?: AuthApi(activity ?: return).also { authApi = it }
        try {
            val response = api.getAuthResponseFromIntent(
                intent,
                TikTokConfig.REDIRECT_URI
            ) ?: return

            if (response.authCode.isNotEmpty()) {
                emitSignal(
                    AUTH_SUCCESS.name,
                    response.authCode,
                    response.grantedPermissions ?: ""
                )
            } else if (response.errorCode != 0) {
                emitSignal(
                    AUTH_ERROR.name,
                    response.authErrorDescription
                        ?: response.authMsg
                        ?: response.errorMsg
                        ?: "TikTok rechazó la autorización."
                )
            }
        } catch (e: Exception) {
            emitSignal(
                AUTH_ERROR.name,
                e.message ?: "Error procesando el callback de TikTok."
            )
        }
    }

    private fun isPackageInstalled(packageName: String): Boolean {
        val ctx = activity?.applicationContext ?: return false
        return try {
            ctx.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }
}
